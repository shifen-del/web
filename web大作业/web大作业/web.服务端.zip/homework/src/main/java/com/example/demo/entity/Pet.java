package com.example.demo.entity;

public class Pet {
    private Integer petId;
    private String petBreed;
    private String desc;
    private Double price;

    public Pet() {
    }

    @Override
    public String toString() {
        return "Pet{" +
                "petId=" + petId +
                ", petBreed='" + petBreed + '\'' +
                ", price=" + price +
                ", desc='" + desc + '\'' +
                '}';
    }

    public Integer getPetId() {
        return petId;
    }

    public void setPetId(Integer petId) {
        this.petId = petId;
    }

    public String getPetBreed() {
        return petBreed;
    }

    public void setPetBreed(String petBreed) {
        this.petBreed = petBreed;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }
}
