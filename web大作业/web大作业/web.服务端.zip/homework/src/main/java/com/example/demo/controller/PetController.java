package com.example.demo.controller;

import com.example.demo.biz.PetBiz;
import com.example.demo.entity.Pet;
import com.example.demo.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class PetController {
    @Autowired
    private PetBiz biz;
    @RequestMapping("/pet/list")
    public Map findPets()
    {
        List<Pet> list = biz.findAll();
        Map result = new HashMap<>();
        result.put("isOk", true);
        result.put("msg", "查询成功");
        result.put("pets", list);
        System.out.println(list);
        return result;
    }

    @RequestMapping("/pet/add")
    public Map add(Pet pet){
        this.biz.addPet(pet);
        Map result = new HashMap<>();
        result.put("isOk", true);
        result.put("msg", "添加成功");
        return result;
    }

    @RequestMapping("/pet/update")
    public Map update(Pet pet, HttpServletRequest request)
    {
        System.out.println(pet.toString());
        Map<String, Object> result = new HashMap<>();
        biz.upPet(pet);
        result.put("isOk",true);
        return result;
    }

    @RequestMapping("/pet/del")
    public Map del(int petId){
        System.out.println(petId);
        Map result = new HashMap<>();
        if(this.biz.delPet(petId)){
            result.put("isOk", true);
            result.put("msg", "删除成功");
        } else {
            result.put("isOk", false);
            result.put("msg", "删除失败");
        }

        return result;
    }
    public void setBiz(PetBiz biz) {
        this.biz = biz;
    }

}
