package com.example.demo.controller;

import com.example.demo.biz.UserBiz;
import com.example.demo.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController //Controller+ResponseBody
public class UserController {

    @Autowired
    private UserBiz biz;
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @RequestMapping("/user/check")
   public Map check(HttpServletRequest request)
    {
        Map<String, Object> result = new HashMap<>();
        HttpSession session = request.getSession();
        User user=(User)session.getAttribute("user_login");
        if(user!=null)
        {
            result.put("check",true);
        }else {
            result.put("check",false);
        }
        return result;
    }

    @RequestMapping("/user/update")
    public Map update(User user,HttpServletRequest request)
    {
        Map<String, Object> result = new HashMap<>();
        biz.upUser(user);
        result.put("isOk",true);
        return result;
    }

    @RequestMapping("/user/login")
    public Map login(User user, HttpSession session){
        User userr = biz.checkLogin(user);
        session.setAttribute("user_login",userr);
        Map map = new HashMap();
        map.put("isOk",true);
        map.put("user",user);
        map.put("msg","登录成功");
        return map;
    }

    @RequestMapping("/user/register")
    public Map<String, Object> register(User user, HttpServletRequest request) {
        Map<String, Object> result = new HashMap<>();
        try {
            // 1. 添加用户到数据
            // 2. 设置用户权限
            biz.addUser(user);
            // 3. 获取最后插入的自增长ID
            Integer userId = jdbcTemplate.queryForObject("SELECT LAST_INSERT_ID()", Integer.class);
            // 4. 构建返回给客户端的信息
            result.put("isOk", true);
            result.put("msg", "注册成功");
            result.put("userId", userId);
            // 5. 将用户添加到session中
            HttpSession session = request.getSession();
            session.setAttribute("user", user);

        } catch (Exception e) {
            result.put("isOk", false);
            result.put("msg", "注册失败");
            e.printStackTrace();
        }

        return result;
    }

    @RequestMapping("/user/add")
    public Map add(User user) {
        biz.addUser(user);
        Map result = new HashMap<>();
        result.put("isOk", true);
        result.put("msg", "添加成功");
        return result;
    }

    @RequestMapping("/user/del")
    public Map del(String account) {
        Map result = new HashMap<>();
        if (biz.delUser(account)) {
            result.put("isOk", true);
            result.put("msg", "删除成功");
        } else {
            result.put("isOk", false);
            result.put("msg", "删除失败");
        }
        return result;
    }

    @RequestMapping("/user/list")
    public Map findUsers() {
        List<User> list = biz.findAll();
        Map result = new HashMap<>();
        result.put("isOk", true);
        result.put("msg", "查询成功");
        result.put("users", list);
        System.out.println(list);
        return result;
    }

    public void setBiz(UserBiz biz) {
        this.biz = biz;
    }
}
