package com.example.demo.util;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.Map;

@ControllerAdvice
public class ExceptionHandler {
    @org.springframework.web.bind.annotation.ExceptionHandler
    @ResponseBody
    public Map JsonError(Exception e){
        Map map = new HashMap();
        map.put("isOk",false);

        if(e instanceof MyException){
            map.put("msg",e.getMessage());
        }else {
            map.put("msg","系统错误，请联系管理员");
        }
        return map;
    }
}
