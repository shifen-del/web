package com.example.demo.biz;

import com.example.demo.entity.User;
import com.example.demo.mapper.UserMapper;
import com.example.demo.util.MyException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserBiz {

    @Autowired
    private UserMapper userMapper;

    public List<User> findAll() {
        return userMapper.selectAllUsers();
    }

    public void addUser(User user) {
        userMapper.insertUser(user);
    }

    public User checkLogin(User user){
        User dbUser = userMapper.selectUserById(user.getAccount());
        if(dbUser!=null && dbUser.getPassword().equals(user.getPassword())){
            return dbUser;
        }else {
            throw new MyException("登录失败，账号不存在或密码错误");
        }
    }

    public void upUser(User user){
       userMapper.updateUser(user);
    }
    public boolean delUser(String account) {
        return userMapper.deleteUserById(account) > 0;
    }

    public void setUserMapper(UserMapper userMapper) {
        this.userMapper = userMapper;
    }
}
