package com.example.demo.mapper;

import com.example.demo.entity.User;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface UserMapper {

    @Select("SELECT * FROM t_user")
    List<User> selectAllUsers(); // 查询所有用户信息

    @Insert("INSERT INTO t_user VALUES (#{account},#{password})")
    void insertUser(User user); // 添加用户信息

    @Delete("DELETE FROM t_user WHERE account = #{account}")
    int deleteUserById(String account); // 根据用户编号删除用户

    @Select("SELECT * FROM t_user WHERE account = #{account}")
    User selectUserById(String account); // 根据编号查找用户

    @Update("UPDATE t_user SET password = #{password} WHERE account = #{account}")
    void updateUser(User user);
}