package com.example.demo.biz;

import com.example.demo.entity.Pet;
import com.example.demo.mapper.PetMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PetBiz {
    @Autowired
    private PetMapper petMapper;

    public List<Pet> findAll()
    {
        return petMapper.selectPets();
    }
    public void addPet(Pet pet){
        this.petMapper.insertPet(pet);
    }
    public boolean delPet(int petId){
        return this.petMapper.deletePetById(petId)>0;
    }

    public void setPetMapper(PetMapper petMapper) {
        this.petMapper = petMapper;
    }

    public void upPet(Pet pet){
        petMapper.updatePet(pet.getPetBreed(), pet.getDesc(),pet.getPrice(),pet.getPetId());
    }
}
