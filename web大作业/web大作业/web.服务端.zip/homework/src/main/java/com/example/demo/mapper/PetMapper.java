package com.example.demo.mapper;

import com.example.demo.entity.Pet;
import com.example.demo.entity.User;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface PetMapper {

    @Select("select * from t_pet")
    List<Pet> selectPets();//列举宠物信息

    @Insert("insert into t_pet values(null,#{petBreed},#{desc},#{price})")
    void insertPet(Pet pet);//添加宠物信息

    @Delete("delete from t_pet where petId=#{petId}")
    int deletePetById(int petId); //删除宠物

    @Select("select * from t_pet where petId=#{petId}")
    Pet selectPetById(int petId);//根据编号查找宠物

    @Update("UPDATE t_pet SET petBreed = #{petBreed} WHERE petId = #{petId}")
    void updatePet(@Param("petBreed") String petBreed, @Param("desc") String desc, @Param("price") Double price, @Param("petId") Integer petId);

}
