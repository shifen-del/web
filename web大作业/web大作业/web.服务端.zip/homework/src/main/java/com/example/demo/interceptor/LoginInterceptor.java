package com.example.demo.interceptor;

import com.example.demo.entity.User;
import com.example.demo.util.MyException;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@Component
public class LoginInterceptor implements HandlerInterceptor {
    //执行的时机:在要访问的controller之前执行preHandle;
    //拦截器最常用的是preHandle方法，返回值为布尔型，返回true则可以继续执行下去，返回false就不能往下访问了
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        System.out.println("begin Interceptor");
        Object user = request.getSession().getAttribute("user_login");
        System.out.println("login user: "+user);
        if(user==null){
            throw new MyException("错误，未登录或登录失效，请重新登录后在执行");
        }
        return true;
    }
    //在控制器访问完成后postHandle;
    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
        System.out.println("end Interceptor");
    }
    //如果遇到控制器内部跳转的话在一系列跳转都跳完之后会执行afterCompletion
    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {

    }
}
